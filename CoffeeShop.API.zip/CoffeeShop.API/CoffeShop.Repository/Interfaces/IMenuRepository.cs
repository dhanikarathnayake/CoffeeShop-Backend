﻿using CoffeShop.Model;
using CoffeShop.Model.ViewModles;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoffeShop.Repository.Interfaces
{
    public interface IMenuRepository
    {
        void SetRequest(HttpRequest httpRequest);
        Task<BaseResponse> SelectMenu();
        Task<BaseResponse> InsertMenuDetails(Menu Menu);

    }
}
