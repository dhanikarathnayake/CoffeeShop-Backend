﻿using CoffeShop.Model;
using CoffeShop.Model.ViewModles;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoffeShop.Repository.Interfaces
{
   public interface ICustomerRepository
    {
        void SetRequest(HttpRequest httpRequest);
        Task<BaseResponse> SelectCustomerDetails();
        Task<BaseResponse> InsertCustomerDetails(CustomerDetail CustomerDetail);
    }
}
