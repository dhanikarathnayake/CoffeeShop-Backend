﻿using CoffeShop.Model;
using CoffeShop.Model.ViewModles;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoffeShop.Repository.Interfaces
{
    public interface IPaymentRepository
    {
        void SetRequest(HttpRequest httpRequest);
        Task<BaseResponse> SelectPaymentMethod();
        Task<BaseResponse> InsertPayment(Payment Payment);
        Task<BaseResponse> SelectPaymentDetails();

    }
}
