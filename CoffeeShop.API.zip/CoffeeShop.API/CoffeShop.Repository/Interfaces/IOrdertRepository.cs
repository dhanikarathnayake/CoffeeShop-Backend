﻿using CoffeShop.Model;
using CoffeShop.Model.ViewModles;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoffeShop.Repository.Interfaces
{
   public interface IOrdertRepository
    {
        void SetRequest(HttpRequest httpRequest);
        Task<BaseResponse> InsertOrder(Order Order);
        Task<BaseResponse> SelectOrderDetails();
    }
}
