﻿using System;

namespace CoffeShop.Repository
{
    public class Class1
    {
    }
}
