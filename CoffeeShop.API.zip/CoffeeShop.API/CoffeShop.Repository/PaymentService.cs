﻿using CoffeShop.Model;
using CoffeShop.Model.ViewModles;
using CoffeShop.Repository.Interfaces;
using Dapper;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace CoffeShop.Repository
{
    public class PaymentService : IPaymentRepository
    {
        private readonly string _connectionString;
       private HttpRequest _request;

        public PaymentService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void SetRequest(HttpRequest httpRequest)
        {
            this._request = httpRequest;
        }

        public async Task<BaseResponse> SelectPaymentMethod()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    DynamicParameters para = new DynamicParameters();

                    var results = await connection.QueryAsync<PaymentMethodVM>("[dbo].[SelectPaymentMethod]", para, commandType: CommandType.StoredProcedure);

                    return new BaseResponseService().GetSuccessResponse(results);
                }
            }

            catch (SqlException ex)
            {
                
                return new BaseResponseService().GetErrorResponse(ex);
            }
            catch (Exception ex)
            {
                
                return new BaseResponseService().GetErrorResponse(ex);
            }
        }

        public async Task<BaseResponse> InsertPayment(Payment Payment)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    DynamicParameters para = new DynamicParameters();
                    string JsonData = JsonConvert.SerializeObject(Payment);
                    para.Add("@JsonData", JsonData, DbType.String);

                    await connection.ExecuteAsync("[dbo].[InsertPaymentDetails]", para, commandType: CommandType.StoredProcedure);

                    return new BaseResponseService().GetSuccessResponse();
                }
            }
            catch (SqlException ex)
            {
                return new BaseResponseService().GetErrorResponse(ex);
            }
            catch (Exception ex)
            {
                return new BaseResponseService().GetErrorResponse(ex);
            }
        }

        public async Task<BaseResponse> SelectPaymentDetails()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    DynamicParameters para = new DynamicParameters();

                    var results = await connection.QueryAsync<PaymentDetails>("[dbo].[SelectPaymentDetails]", para, commandType: CommandType.StoredProcedure);

                    return new BaseResponseService().GetSuccessResponse(results);
                }
            }

            catch (SqlException ex)
            {

                return new BaseResponseService().GetErrorResponse(ex);
            }
            catch (Exception ex)
            {

                return new BaseResponseService().GetErrorResponse(ex);
            }
        }
    }
}
