﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model
{
   public class Order
    {
        public int MenuID { get; set; }
        public int CustomerDetailID { get; set; }
        public int PaymentMethodID { get; set; }
    }
}
