﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model
{
    public class Menu
    {
        public string MenuName { get; set; }
        public string MenuPrice { get; set; }
    }
}
