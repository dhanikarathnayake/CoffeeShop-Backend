﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model
{
    public class Payment
    {
        public int OrderID { get; set; }
        public int PaymentMethodID { get; set; }
        public string CardNumber {get;set;}
        public string Status { get; set; }
        public string PaymentBy { get; set; }
        public string PaymentOn { get; set; }
    }
}
