﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model.ViewModles
{
   public class CustomerDetailsVM
    {
        public int CustomerDetailID { get; set; }
        public string CustomerName { get; set; }
        public string CustID { get; set; }
        public string TelephoneNo { get; set; }
        public string Address { get; set; }

    }
}
