﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model.ViewModles
{
   public class PaymentMethodVM
    {
        public int PaymentMethodID { get; set; }
        public string PaymentMethodDescription { get; set; }
    }

    public class PaymentDetails
    {
        public string MenuName { get; set; }
        public string ItemPrice { get; set; }
        public string CustomerName { get; set; }
        public string PaymentOn { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
    }
}
