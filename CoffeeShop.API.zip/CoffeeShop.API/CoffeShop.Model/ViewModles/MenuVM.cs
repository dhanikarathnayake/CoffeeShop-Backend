﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model.ViewModles
{
    public class MenuVM
    {
        public int MenuID { get; set; }
        public string MenuName { get; set; }
        public string MenuPrice { get; set; }
    }
}
