﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model.ViewModles
{
    public class OrderDetailVM
    {
        public string MenuName { get; set; }
        public string ItemPrice { get; set; }
        public string CustomerName { get; set; }
        public string InsertBy { get; set; }
        public string InsertOn { get; set; }
    }
}
