﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoffeShop.Model
{
    public class CustomerDetail
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string custid { get; set; }
        public string telephone { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
    }
}
