﻿using System;

namespace CoffeShop.Model
{
    public class Class1
    {
    }
}
