﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoffeShop.Model;
using CoffeShop.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoffeeShop.API.Controllers
{
    [Route("api/CoffeeShop/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentRepository _repository;

        public PaymentController(IPaymentRepository repository)
        {
            _repository = repository;
        }


        [HttpGet("SelectPaymentMethod")]
        public async Task<ActionResult> SelectPaymentMethod()
        {
            _repository.SetRequest(Request);
            var response = await _repository.SelectPaymentMethod();

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError, response);
        }


        [HttpPost("InsertPayment")]
        public async Task<ActionResult> InsertPayment(Payment Payment)
        {
            _repository.SetRequest(Request);
            var response = await _repository.InsertPayment(Payment);

            if (response.Success)
            {
                return Ok(response);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, response);
            }

        }

        [HttpGet("SelectPaymentDetails")]
        public async Task<ActionResult> SelectPaymentDetails()
        {
            _repository.SetRequest(Request);
            var response = await _repository.SelectPaymentDetails();

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError, response);
        }
    }
}