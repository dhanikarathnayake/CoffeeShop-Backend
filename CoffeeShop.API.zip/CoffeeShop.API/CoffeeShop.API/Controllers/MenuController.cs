﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoffeShop.Model;
using CoffeShop.Repository.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoffeeShop.API.Controllers
{
    [Route("api/CoffeeShop/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        private readonly IMenuRepository _repository;

        public MenuController(IMenuRepository repository)
        {
            _repository = repository;
        }
       // [EnableCors("AnotherPolicy")]
        [HttpGet("SelectMenu")]
        public async Task<ActionResult> SelectMenu()
        {
            _repository.SetRequest(Request);
            var response = await _repository.SelectMenu();

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError, response);
        }

        [HttpPost("InsertMenuDetails")]
        public async Task<ActionResult> InsertMenuDetails(Menu Menu)
        {
            _repository.SetRequest(Request);
            var response = await _repository.InsertMenuDetails(Menu);

            if (response.Success)
            {
                return Ok(response);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, response);
            }

        }
    }
}