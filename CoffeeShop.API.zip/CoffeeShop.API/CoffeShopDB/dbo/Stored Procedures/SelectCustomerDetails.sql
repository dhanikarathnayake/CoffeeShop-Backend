﻿
-- =================================================
-- Author		: Dhanika Rathnayake
-- Created date	: 2021-05-08
-- Modified date: 2021-05-08 
-- Description	: Select Customer Details
-- =================================================

CREATE PROCEDURE [dbo].[SelectCustomerDetails] 

AS
BEGIN	  
    DECLARE @sErrorProcedure	VARCHAR(200),
			@sLog				VARCHAR(500),
			@sErrorMessage		VARCHAR(500),						
			@MsgText			VARCHAR(1000),
			@Validation			VARCHAR(1000),	
			@IsValidation		BIT

		BEGIN TRY	
	
			  SET @IsValidation=0
		
			SELECT 
				CustomerDetailID AS CustomerDetailID,
				CustomerName AS CustomerName,
				CustID AS CustID,
				TelephoneNo AS TelephoneNo,
				Address AS Address
			FROM [dbo].[CustomerDetails]
			WHERE ISNULL(IsActive,0)=1

		

			RETURN 1
		END TRY
		BEGIN CATCH		
		
			DECLARE @iErrorNumber INT

			SELECT	@sErrorProcedure=ERROR_PROCEDURE()
			SELECT	@sErrorMessage=ERROR_MESSAGE()
			SELECT	@iErrorNumber=ERROR_NUMBER()

			IF @IsValidation=1
			BEGIN
				EXEC sp_addmessage @MsgNum=50005,@Severity=1,@MsgText=@Validation,@Replace='replace';
				RAISERROR (50005,16,1)
			END
			ELSE
				RAISERROR (@sErrorMessage,16,1)
		
			SELECT * 
			FROM sys.messages
			WHERE message_id=50005

			EXEC sp_dropmessage 50005;	

			RETURN 0
  
		END CATCH  
END
