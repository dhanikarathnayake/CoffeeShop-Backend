﻿-- =============================================
-- Author		: Dhanika Rathnayake
-- Create date	: 2021-05-08
-- Description	: Insert Payment Details
-- =============================================
CREATE PROCEDURE [dbo].[InsertPaymentDetails] 
	
	@JsonData		VARCHAR(MAX)
AS
BEGIN
	SET XACT_ABORT,
	QUOTED_IDENTIFIER,
	ARITHABORT,
	ANSI_NULLS,
	ANSI_PADDING,
	ANSI_WARNINGS,
	CONCAT_NULL_YIELDS_NULL ON;
	SET NUMERIC_ROUNDABORT OFF;
  
    DECLARE @sErrorProcedure		VARCHAR(200),
			@sLog					VARCHAR(500),
			@sErrorMessage			VARCHAR(500),
			@MsgText				VARCHAR(1000),
			@Validation				VARCHAR(1000),
			@IsValidation			BIT
			

    BEGIN TRY


	IF OBJECT_ID('tempdb..#PaymentDetails') IS NOT NULL 
		DROP TABLE #PaymentDetails

	CREATE TABLE #PaymentDetails
	(
		ID									INT IDENTITY(1,1),
		OrderID								INT,
		PaymentMethodID						INT,
		CardNumber							VARCHAR(500),
		Status								VARCHAR(5),
		PaymentBy							VARCHAR(50),
		PaymentOn							VARCHAR(50)

	)

DECLARE	@OrderID								INT,
		@PaymentMethodID						INT,
		@CardNumber							VARCHAR(500),
		@Status								VARCHAR(5),
		@PaymentBy							VARCHAR(50),
		@PaymentOn							VARCHAR(50)
	
						
	BEGIN TRANSACTION
			

		INSERT INTO #PaymentDetails( OrderID,PaymentMethodID,CardNumber,Status,PaymentBy,PaymentOn) 
		SELECT OrderID,PaymentMethodID,CardNumber,Status,PaymentBy,PaymentOn
		FROM 
		OPENJSON(@JsonData) 
		WITH (
				OrderID								INT,
				PaymentMethodID						INT,
				CardNumber							VARCHAR(500),
				Status								VARCHAR(5),
				PaymentBy							VARCHAR(50),
				PaymentOn							VARCHAR(50)
			)



	IF (SELECT COUNT(1) FROM #PaymentDetails tm) > 1
	BEGIN
		SET @IsValidation=1
		SET @Validation='Request not allowed.!'
		RAISERROR (50005,16,1)
		RETURN 0;
	END

			SELECT	
					@OrderID=OrderID,
					@PaymentMethodID=PaymentMethodID,
					@CardNumber=CardNumber,
					@Status=Status,
					@PaymentBy=PaymentBy,
					@PaymentOn=PaymentOn

			FROM #PaymentDetails
				
				IF (@OrderID IS NULL)
				BEGIN
					SET @IsValidation=1
					SET @Validation='Order Detail Cannot be Empty...!'
					RAISERROR (50005,16,1)
					RETURN 0;
				END

				IF (@PaymentMethodID IS NULL)
				BEGIN
					SET @IsValidation=1
					SET @Validation='Payment MethodID Cannot be Empty...!'
					RAISERROR (50005,16,1)
					RETURN 0;
				END

				IF EXISTS (SELECT * FROM PaymentMethod WHERE PaymentMethodID=@PaymentMethodID AND ISNULL(PaymentMethodDescription,'')<>'Cash' )
				BEGIN
					IF (@CardNumber IS NULL)
					BEGIN
						SET @IsValidation=1
						SET @Validation='CardNumber Cannot be Empty...!'
						RAISERROR (50005,16,1)
						RETURN 0;
					END
				END
			
				INSERT INTO PaymentDetails( OrderID,PaymentMethodID,CardNumber,Status,PaymentBy,PaymentOn) 
				SELECT @OrderID,@PaymentMethodID,@CardNumber,@Status,@PaymentBy,@PaymentOn

		


	IF @@TRANCOUNT>0
			COMMIT TRANSACTION
		
		RETURN 1

	END TRY
	BEGIN CATCH
		
		IF @@TRANCOUNT>0
			ROLLBACK TRANSACTION
		DECLARE @iErrorNumber INT

		SELECT	@sErrorProcedure=ERROR_PROCEDURE()
		SELECT	@sErrorMessage=ERROR_MESSAGE()
		SELECT	@iErrorNumber=ERROR_NUMBER()

		IF @IsValidation=1
		BEGIN
			EXEC sp_addmessage @MsgNum=50005,@Severity=1,@MsgText=@Validation,@Replace='replace';
			RAISERROR (50005,16,1)
		END
		ELSE
			RAISERROR (@sErrorMessage,16,1)
		
		SELECT * 
		FROM sys.messages
		WHERE message_id=50005

		EXEC sp_dropmessage 50005;	

		RETURN 0
  
    END CATCH  
END