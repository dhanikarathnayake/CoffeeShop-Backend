﻿CREATE TABLE [dbo].[CustomerDetails] (
    [CustomerDetailID] BIGINT        IDENTITY (1, 1) NOT NULL,
    [CustomerName]     VARCHAR (500) NULL,
    [CustID]           VARCHAR (50)  NULL,
    [TelephoneNo]      VARCHAR (50)  NULL,
    [Address]          VARCHAR (500) NULL,
    [IsActive]         BIT           NULL
);

