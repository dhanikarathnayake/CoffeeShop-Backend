﻿CREATE TABLE [dbo].[Menu] (
    [MenuID]    INT           IDENTITY (1, 1) NOT NULL,
    [MenuName]  VARCHAR (100) NULL,
    [MenuPrice] VARCHAR (50)  NULL,
    [IsActive]  BIT           NULL
);

