﻿CREATE TABLE [dbo].[PaymentDetails] (
    [PaymentID]       BIGINT       IDENTITY (1, 1) NOT NULL,
    [OrderID]         BIGINT       NULL,
    [PaymentMethodID] SMALLINT     NULL,
    [CardNumber]      VARCHAR (50) NULL,
    [Status]          VARCHAR (2)  NULL,
    [PaymentBy]       VARCHAR (50) NULL,
    [PaymentOn]       VARCHAR (50) NULL
);

