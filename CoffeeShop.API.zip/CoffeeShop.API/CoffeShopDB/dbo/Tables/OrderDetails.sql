﻿CREATE TABLE [dbo].[OrderDetails] (
    [OrderID]          INT           IDENTITY (1, 1) NOT NULL,
    [MenuID]           INT           NULL,
    [CustomerDetailID] INT           NULL,
    [IsActive]         BIT           NULL,
    [InsertBy]         VARCHAR (500) NULL,
    [InsertOn]         VARCHAR (50)  NULL
);

