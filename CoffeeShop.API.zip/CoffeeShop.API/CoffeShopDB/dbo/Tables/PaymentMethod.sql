﻿CREATE TABLE [dbo].[PaymentMethod] (
    [PaymentMethodID]          SMALLINT     IDENTITY (1, 1) NOT NULL,
    [PaymentMethodDescription] VARCHAR (50) NULL,
    [IsActive]                 BIT          NULL
);

