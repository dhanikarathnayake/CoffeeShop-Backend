﻿-- =============================================
-- Author		: Dhanika Rathnayake
-- Create date	: 2021-05-08
-- Description	: Insert Menu Details
-- =============================================
CREATE PROCEDURE [dbo].[InsertMenuDetails] 
	
	@JsonData		VARCHAR(MAX)
AS
BEGIN
	SET XACT_ABORT,
	QUOTED_IDENTIFIER,
	ARITHABORT,
	ANSI_NULLS,
	ANSI_PADDING,
	ANSI_WARNINGS,
	CONCAT_NULL_YIELDS_NULL ON;
	SET NUMERIC_ROUNDABORT OFF;
  
    DECLARE @sErrorProcedure		VARCHAR(200),
			@sLog					VARCHAR(500),
			@sErrorMessage			VARCHAR(500),
			@MsgText				VARCHAR(1000),
			@Validation				VARCHAR(1000),
			@IsValidation			BIT
			

    BEGIN TRY


	IF OBJECT_ID('tempdb..#MenuDetails') IS NOT NULL 
		DROP TABLE #MenuDetails

	CREATE TABLE #MenuDetails
	(
		ID					INT IDENTITY(1,1),
		MenuName			VARCHAR(500),
		MenuPrice			VARCHAR(500)

	)

DECLARE	@MenuName	VARCHAR(500),
		@MenuPrice	VARCHAR(500)
	
						
	BEGIN TRANSACTION
			

		INSERT INTO #MenuDetails(MenuName,MenuPrice) 
		SELECT MenuName,MenuPrice
		FROM 
		OPENJSON(@JsonData) 
		WITH (
				MenuName			VARCHAR(500),
				MenuPrice			VARCHAR(500)
			)

	IF (SELECT COUNT(1) FROM #MenuDetails tm) > 1
	BEGIN
		SET @IsValidation=1
		SET @Validation='Request not allowed.!'
		RAISERROR (50005,16,1)
		RETURN 0;
	END
			SELECT	
					@MenuName=MenuName,
					@MenuPrice=MenuPrice
			FROM #MenuDetails
							
				INSERT INTO Menu(MenuName,MenuPrice,[IsActive]) 
				SELECT  @MenuName,@MenuPrice,1


	IF @@TRANCOUNT>0
			COMMIT TRANSACTION
		
		RETURN 1

	END TRY
	BEGIN CATCH
		
		IF @@TRANCOUNT>0
			ROLLBACK TRANSACTION
		DECLARE @iErrorNumber INT

		SELECT	@sErrorProcedure=ERROR_PROCEDURE()
		SELECT	@sErrorMessage=ERROR_MESSAGE()
		SELECT	@iErrorNumber=ERROR_NUMBER()

		IF @IsValidation=1
		BEGIN
			EXEC sp_addmessage @MsgNum=50005,@Severity=1,@MsgText=@Validation,@Replace='replace';
			RAISERROR (50005,16,1)
		END
		ELSE
			RAISERROR (@sErrorMessage,16,1)
		
		SELECT * 
		FROM sys.messages
		WHERE message_id=50005

		EXEC sp_dropmessage 50005;	

		RETURN 0
  
    END CATCH  
END